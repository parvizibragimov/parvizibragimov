
http://isites.harvard.edu/course/colgsas-2019

https://www.youtube.com/watch?v=apuftlcru90&list=pl09hhnlamguoh-m56t8zm5yh6og-_ufi5

http://www.fisica.net/ebooks/classical_mechanics_goldstein_3ed.pdf

https://cimec.org.ar/foswiki/pub/Main/Cimec/MecanicaRacional/84178116-Vol-1-Landau-Lifshitz-Mechanics-3Rd-Edition-197P.pdf

http://www.damtp.cam.ac.uk/user/tong/dynamics.html



http://fulviofrisone.com/attachments/article/209/Landau%20L.D.%20Lifschitz%20E.M.-%20Vol.%202%20-%20The%20Classical%20Theory%20of%20Fields.pdf

http://farside.ph.utexas.edu/teaching/jk1/jk1.html

http://users.ox.ac.uk/~math0391/emlectures.pdf

http://www.mth.uct.ac.za/omei/gr/

http://www.damtp.cam.ac.uk/user/tong/statphys.html

http://oer.physics.manchester.ac.uk/qm/

http://ocw.mit.edu/courses/physics/8-321-quantum-theory-i-fall-2002/


https://www.mathematik.hu-berlin.de/~berg/functional_analysis_seminar_2010_03_29.pdf

https://www.staff.science.uu.nl/~hooft101/lectures/lieg.html


http://iate.oac.uncor.edu/~manuel/libros/modern%20physics/quantum%20field%20theory/an%20introduction%20to%20quantum%20field%20theory%20%20-%20peskin%20and%20schroeder.pdf



https://www.scribd.com/doc/56223561/weinberg-the-quantum-theory-of-fields-vol-1-foundations weinberg 




http://iate.oac.uncor.edu/~manuel/libros/modern%20physics/general%20relativity%20theory/gravitation%20and%20cosmology%20principles%20and%20applications%20of%20the%20general%20theory%20of%20relativity%20-%20weinberg%20s..pdf

http://iate.oac.uncor.edu/~manuel/libros/modern%20physics/mathematical%20physics/modern%20differential%20geometry%20for%20physicists%202nd%20ed.,%20-%20c.%20isham.pdf


https://loshijosdelagrange.files.wordpress.com/2013/04/v-arnold-mathematical-methods-of-classical-mechanics-1989.pdf

http://zainab-alfull.com/wp-content/uploads/2014/02/elementary-particles-griffiths.pdf

https://www.perimeterinstitute.ca/training/perimeter-scholars-international/lectures/2014/2015-psi-lectures


http://arxiv.org/abs/0905.4630

http://users.uoa.gr/~alahanas/documents/corfu09_lec1.pdf

http://stringworld.ru/files/dine_m._supersymmetry_and_string_theory.pdf

http://lanl.arxiv.org/pdf/hep-th/9709062v2.pdf

http://www.itp.phys.ethz.ch/research/qftstrings/lectures.html

http://arxiv.org/pdf/hep-th/9305026v1.pdf 





http://www.fulviofrisone.com/attachments/article/453/weinberg,%20steven%20-%20the%20quantum%20theory%20of%20fields%20volume%20ii.pdf

http://www.phy.olemiss.edu/~hamed/quarks_and_leptons.pdf 

http://www.cs.indiana.edu/~hansona/papers/eguchigilkeyhanson1980.pdf

http://arxiv.org/pdf/astro-ph/0401547v1.pdf

http://arxiv.org/abs/0802.3688

http://background.uchicago.edu/~whu/araa/araa.html

http://mural.uv.es/rusanra/lie%20algebras%20in%20particle%20physics%202%c2%aa%20ed%20-%20from%20isospin%20to%20unified%20theories%20(georgi,%201999).pdf

http://arxiv.org/abs/0908.0333

http://iate.oac.uncor.edu/~manuel/libros/astrophysics/cosmology/the%20physics%20of%20the%20early%20universe%20-%20papantonopoulos.pdf


arxiv:1208.5504 [hep-ph]

arxiv:1406.1786 [hep-ph]

arxiv:1101.0593 [hep-ph]

arxiv:1307.1347 [hep-ph]

https://www.univie.ac.at/lunch-seminar/talks2009/f-th-wien.pdf 





http://www.springer.com/us/book/9783540533429

http://www.maths.ed.ac.uk/~aar/papers/mfaknot.pdf

http://media.scgp.stonybrook.edu/presentations/20101103_atiyah_-_from_algebraic_geometry_to_physics.pdf 

http://wwwf.imperial.ac.uk/~skdona/ymills.pdf 

http://www.cimat.mx/~luis/seminarios/teoria-k/atiyah_k_theory_advanced.pdf 


http://www.maths.ed.ac.uk/~aar/atiyahedinburghlectures.pdf



http://www.math.toronto.edu/mgualt/morse%20theory/witten%20morse%20theory%20and%20supersymmetry.pdf 

http://math.ucr.edu/~alex/cobordism_lecture5.pdf

http://www.mathematik.uni-muenchen.de/~schotten/qftcs/qftcs_notes-drews.pdf



http://arxiv.org/pdf/gr-qc/0308048.pdf

http://www.damtp.cam.ac.uk/user/pz229/research_files/qftcs.pdf

http://www.maths.ed.ac.uk/~aar/papers/atiyahinttqft.pdf


https://math.berkeley.edu/~teleman/math/barclect.pdf 

http://users.math.yale.edu/~dga4/tqftnotes.pdf



http://arxiv.org/abs/physics/9709045 k

http://arxiv.org/abs/hep-th/9908142 

http://www.amazon.com/exec/obidos/asin/0852740956/thesuperstring07

http://stringworld.ru/files/nakahara_m._geometry_topology_and_physics_2nd_ed..pdf